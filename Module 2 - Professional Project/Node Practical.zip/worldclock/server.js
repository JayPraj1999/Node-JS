const express = require('express');
const moment = require('moment-timezone');

const app = express();
const port = 3000;

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Mapping of countries to their time zones
const countryTimeZones = {
    'United States': [
        'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles'
    ],
    'United Kingdom': ['Europe/London'],
    'Japan': ['Asia/Tokyo'],
    'Australia': ['Australia/Sydney', 'Australia/Melbourne'],
    // Add more countries and their time zones as needed
};

// Route to get time for a specific time zone
app.get('/time/:zone', (req, res) => {
    const timeZone = req.params.zone;
    const validTimeZones = moment.tz.names();
    
    if (validTimeZones.includes(timeZone)) {
        const time = moment().tz(timeZone).format('YYYY-MM-DD HH:mm:ss');
        res.json({ time, timeZone });
    } else {
        res.status(400).json({ error: 'Invalid time zone' });
    }
});

// Route to get time zones by country
app.get('/timezones/:country', (req, res) => {
    const country = req.params.country;
    const timeZones = countryTimeZones[country];

    if (timeZones) {
        res.json({ timeZones });
    } else {
        res.status(404).json({ error: 'Country not found' });
    }
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
