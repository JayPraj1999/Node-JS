const express = require('express');
const hbs = require('hbs');
const axios = require('axios');
const path = require('path');

const app = express();
const port = 3000;

// Set up Handlebars
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Set up static files
app.use(express.static(path.join(__dirname, 'public')));

// Route to render the home page
app.get('/', (req, res) => {
    res.render('index', { title: 'Weather App' });
});

// Route to get weather data by city
app.get('/weather', async (req, res) => {
    const { city } = req.query;

    if (!city) {
        return res.render('index', { title: 'Weather App', error: 'City is required' });
    }

    try {
        const weatherResponse = await axios.get(`https://api.openweathermap.org/data/2.5/weather`, {
            params: {
                q: city,
                appid: '4f0a8998e5d1984a6324c53792d2dba02e66474851cbcb9e4871323e96055011', // Replace with your API key
                units: 'metric'
            }
        });
        
        if (weatherResponse.data.cod === '404') {
            return res.render('index', { title: 'Weather App', error: 'City not found' });
        }

        const weatherData = weatherResponse.data;
        res.render('weather', {
            title: 'Weather App',
            city: weatherData.name,
            weather: weatherData.weather[0].description,
            temperature: weatherData.main.temp
        });
    } catch (error) {
        console.error('Error fetching weather data:', error);
        res.render('index', { title: 'Weather App', error: 'Error fetching weather data' });
    }
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
